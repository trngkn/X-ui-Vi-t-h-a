# X-ui full việt hóa
Hỗ trợ bảng điều khiển xray đa giao thức và nhiều người dùng

# Đặc trưng
- Giám sát tình trạng hệ thống
-Hỗ trợ đa người dùng và đa giao thức, hoạt động trực quan hóa trang web
-Giao thức được hỗ trợ: vmess, vless, trojan, shadowsocks, dokodemo-door, tất, http
-Hỗ trợ cấu hình nhiều cấu hình truyền hơn
- Thống kê lưu lượng, giới hạn lưu lượng, giới hạn thời gian hết hạn
-Mẫu cấu hình xray có thể tùy chỉnh
-Hỗ trợ bảng điều khiển truy cập https (mang theo tên miền + chứng chỉ ssl của riêng bạn)
-Các mục cấu hình nâng cao hơn, xem bảng điều khiển để biết chi tiết

# Cài đặt & Nâng cấp
```
bash <(curl -Ls https://raw.githubusercontent.com/DauDau432/VH_x-ui/main/install.sh)
```

## Hệ thống đề xuất
- CentOS 7+
- Ubuntu 16+
- Debian 8+
